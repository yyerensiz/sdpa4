import java.util.ArrayList;
import java.util.List;

public class Experiment implements Subject {
    private List<Observer> observers = new ArrayList<>();

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void post(String subject, String message) {
        for (Observer observer : observers) {
            if (observer instanceof Observation) {
                Observation participant = (Observation) observer;
                    observer.update(subject + " is: \"" + message + "\"");
            }
        }
    }
}
