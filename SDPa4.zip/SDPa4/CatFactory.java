public class CatFactory implements ObservationFactory {
    @Override
    public Observation createSubject(String subjectName) {
        return new Observation("Cat", subjectName);
    }
}