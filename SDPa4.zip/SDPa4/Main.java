import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;


class Main {
    public static void main(String[] args) {
        Experiment experiment = new Experiment();

        List<Observation> subjects = new ArrayList<>();
        List<ObservationFactory> factories = new ArrayList<>();

        factories.add(new ScientistFactory());
        factories.add(new CatFactory());

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add participant");
            System.out.println("2. Remove a participant");
            System.out.println("3. Conduct experiment");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("1. Scientist");
                    System.out.println("2. Cat");
                    System.out.println("Choose the participant type:");

                    int subjectTypeChoice = scanner.nextInt();

                    if (subjectTypeChoice >= 1 && subjectTypeChoice <= factories.size()) {
                        System.out.print("Enter the participant name: ");
                        scanner.nextLine();
                        String subjectName = scanner.nextLine();

                        boolean isDuplicate = subjects.stream().anyMatch(subject -> subject.getSubjectName().equals(subjectName));

                        if (isDuplicate) {
                            System.out.println("A participant with the same name already exists. Please choose another name.");
                        } else {
                            ObservationFactory factory = factories.get(subjectTypeChoice - 1);
                            Observation newSubject = factory.createSubject(subjectName);

                            experiment.addObserver(newSubject);
                            subjects.add(newSubject);
                        }
                    }
                    else {
                        System.out.println("Invalid choice.");
                    }

                    break;
                case 2:
                    System.out.println("Choose participant to delete:");
                    for (int i = 0; i < subjects.size(); i++) {
                        System.out.println((i + 1) + ". " + subjects.get(i).getSubjectName());
                    }

                    int deleteChoice = scanner.nextInt();

                    if (deleteChoice >= 1 && deleteChoice <= subjects.size()) {
                        Observation subjectToDelete = subjects.get(deleteChoice - 1);
                        experiment.removeObserver(subjectToDelete);
                        subjects.remove(subjectToDelete);
                        System.out.println("Participant deleted.");
                    } else {
                        System.out.println("Invalid choice.");
                    }

                    break;
                case 3:
                    if (subjects.isEmpty()) {
                        System.out.println("First, add participants.");
                    } else {
                        System.out.println("Choose a cat to make an experiment:");
                        for (int i = 0; i < subjects.size(); i++) {
                            System.out.println((i + 1) + ". " + subjects.get(i).getSubjectName());
                        }

                        int subjectChoice = scanner.nextInt();

                        if (subjectChoice >= 1 && subjectChoice <= subjects.size()) {
                            Observation chosenSubject = subjects.get(subjectChoice - 1);

                            Random random = new Random();
                            String message;

                            int randomNumber = random.nextInt(2);

                            if (randomNumber == 0) {
                                message = "dead";
                            }
                            else {
                                message = "alive";
                            }


                            experiment.post(chosenSubject.getSubjectName(), message);
                        } else {
                            System.out.println("Invalid choice.");
                        }
                    }

                    break;
                case 4:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}