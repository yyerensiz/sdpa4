public class ScientistFactory implements ObservationFactory {
    @Override
    public Observation createSubject(String subjectName) {
        return new Observation("Scientist", subjectName);
    }
}