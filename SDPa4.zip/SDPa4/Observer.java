public interface Observer {
    void update(String message);
}