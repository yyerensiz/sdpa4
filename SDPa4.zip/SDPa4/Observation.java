
public class Observation implements Observer {

    private String subjectName;

    public Observation(String participantType, String participantName) {
        this.subjectName = participantType + ": " + participantName;
    }

    @Override
    public void update(String message) {
        if (subjectName.startsWith("Scientist")) {

            System.out.println(subjectName + " received a experiment result:");
            System.out.println(message + "\n");
        }
    }

    public String getSubjectName() {
        return subjectName;
    }
}