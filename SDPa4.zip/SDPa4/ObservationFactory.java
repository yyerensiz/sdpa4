public interface ObservationFactory {
    Observation createSubject(String subjectName);
}